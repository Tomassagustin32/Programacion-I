"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _04_claseAbstracta_1 = require("./04_claseAbstracta");
var miAuto = new _04_claseAbstracta_1.Auto("NARANJA", 150, "FIAT");
console.log(miAuto.Mostrar());
miAuto.Acelerar();
//# sourceMappingURL=08_main.js.map