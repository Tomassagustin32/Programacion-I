package controllers;

public enum Actions {
	ADD, DELETE
}