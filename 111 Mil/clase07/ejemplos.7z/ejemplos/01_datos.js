//EJEMPLOS DE TIPOS DE DATOS
var esVerdad = true;
//esVerdad = 0;
//esVerdad = "false";
var entero = 1;
var decimal = 10.59;
var hexa = 0xFF55AA;
var binario = 73;
var octal = 3669;
var obj = null;
var indefinido;
console.log(indefinido);
var cosa = "algo";
cosa = 10;
cosa = true;
var cadena = "hola";
console.log(cadena);
var otraCadena = 'mundo';
console.log(otraCadena);
var masCadenas = "con tilde invertido";
console.log(masCadenas);
var template = "concatenando: " + cadena + " " + otraCadena + ". Valor: " + hexa + ".";
console.log(template);
//# sourceMappingURL=01_datos.js.map